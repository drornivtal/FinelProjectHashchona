﻿using Hashchona.BL;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Hashchona.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CommunitiesController : ControllerBase
    {
        //Get all the Communities
        // GET: api/<CommunitiesController>
        [HttpGet]
        [Route("ReadAllCommunities")]
        public IEnumerable<Community> GetAllCommunities()
        {
            Community community = new Community();
            return community.ReadAllCommunities();
        }

        // GET api/<CommunitiesController>/5
        [HttpGet]
        [Route("ReadApprovedCommunities")]
        public IEnumerable<Community> GetApprovedCommunities()
        {
            Community community = new Community();
            return community.ReadAllApprovedCommunities();
        }

        // GET api/<CommunitiesController>/5
        [HttpGet]
        [Route("ReadPendingCommunities")]
        public IEnumerable<Community> GetPendingCommunities()
        {
            Community community = new Community();
            return community.ReadAllPendingCommunities();
        }

        // POST api/<CommunitiesController>
        [HttpPost]
        [Route("InsertNewCommunity")]

        public int Post(InsertCommunity insertCommunity)
        {
            Community community = new Community();
            return insertCommunity.Insert(insertCommunity.UserManager, insertCommunity.Community);
        }

        // PUT api/<CommunitiesController>/5
        [HttpPut]
        [Route("UpdateCommunityApprovedStatus")]
        public int PutCommunityApprovedStatus([FromBody]int communityID, string approvalStatus)
        {
            Community community = new Community();
            return community.UpdateCommunityApprovalStatus(communityID, approvalStatus);
        }

        // DELETE api/<CommunitiesController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
