﻿using Hashchona.BL;
using Microsoft.AspNetCore.Mvc;
using System.Reflection;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Hashchona.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RequestsForHelpController : ControllerBase
    {
        // GET: api/<AssimentsController>
        [HttpGet]
        [Route("ActiveReqByCommunity")]
        public IEnumerable<RequestForHelp> GetAllActiveReqInCommunity(int CommunityID)
        {
            RequestForHelp assistance = new RequestForHelp();

            return assistance.GetAllActiveReqInCommunity(CommunityID);
        }

        // GET api/<AssimentsController>/5
        [HttpGet]
        [Route("ActiveCategoryReq")]
        public IEnumerable<RequestForHelp> GetAllActiveCategoryReq(int CategoryID, int CommunityID)
        {
            RequestForHelp assistance = new RequestForHelp();
            return assistance.readAllActiveCategoryReq(CategoryID, CommunityID);
        }

        // POST api/<AssimentsController>
        [HttpPost]
        [Route("postNewReq")]
        public int PostNewReq([FromBody] RequestForHelp request)
        {

            return request.InsertNewReq(request);
        }
        
        
        // POST api/<AssimentsController>
        [HttpPost]
        [Route("usersWantToAssist")]
        public int PostNewAssistUser([FromBody] UsersWantToAssist usersWantToAssist)
        {

            return usersWantToAssist.InsertNewUserWantToAssist(usersWantToAssist.User.UserId, usersWantToAssist.RequestForHelp.ReqID);
        }

        // PUT api/<AssimentsController>/5
        [HttpPut]
        [Route("updateUserStatusToReq")]
        public IActionResult PutUserStatusToReq(StatusUpdateToReq statusUpdateToReq)
        {
            int res = statusUpdateToReq.UpdateUserStatusToReq(statusUpdateToReq.User.UserId, statusUpdateToReq.RequestForHelp.ReqID, statusUpdateToReq.StatusApproval);
            if (res == 0)
            {
                return NotFound("Failed to update details,Try again!");
            }
            else
                return Ok(res);
        }
          // PUT api/<AssimentsController>/5
        [HttpPut]
        [Route("updateReqDeatails")]
        public IActionResult PutReq(RequestForHelp request)
        {
            int res = request.UpdateRequest();
            if (res == 0)
            {
                return NotFound("Failed to update details,Try again!");
            }
            else
                return Ok(res);
        }

        // DELETE api/<AssimentsController>/5
        [HttpDelete]
        [Route("DeleteReq")]
        public int DeleteReq(RequestForHelp request)
        {
            return request.DeleteReq(request);
        }
    }
}
