﻿using Hashchona.DAL;

namespace Hashchona.BL
{
    public class Community
    {
        int communityId;
        string name;
        string city;
        string location;
        string description;
        string primaryPic;
        List<User> managers = new List<User>();
        public int CommunityId { get => communityId; set => communityId = value; }
        public string Name { get => name; set => name = value; }
        public string City { get => city; set => city = value; }
        public string Location { get => location; set => location = value; }
        public string Description { get => description; set => description = value; }
        public string PrimaryPic { get => primaryPic; set => primaryPic = value; }
        public List<User> Managers { get => managers; set => managers = value; }

        public Community() { }

        public Community(int communityId, string name, string city, string location, string description, string primaryPic)
        {
            CommunityId = communityId;
            Name = name;
            City = city;
            Location = location;
            Description = description;
            PrimaryPic = primaryPic;            
        }

        //Read all communities list
        public List<Community> ReadAllCommunities()
        {
            DBservices db = new DBservices();

            return db.ReadAllCommunitis();
        }
        //Read all the communities that got approved 
        public List<Community> ReadAllApprovedCommunities()
        {
            DBservices db = new DBservices();

            return db.ReadAllApprovedCommunitis();
        } 
        //Read all the communities that waiting to get approved 
        public List<Community> ReadAllPendingCommunities()
        {
            DBservices db = new DBservices();

            return db.ReadAllPendingCommunities();
        }

     


        //Update Community Approval Status
        public int UpdateCommunityApprovalStatus(int communityId, string approvalStatus)
        {
            DBservices db = new DBservices();
            int NumEffected = db.UpdateCommunityApprovalStatus(communityId, approvalStatus);

            if (approvalStatus == "Approved")
            {
                User user = new User();
                user = db.ReadManagerForSpecificCommunity(communityId);
                Managers.Add(user);
            }

            return NumEffected;
        }

        //Get All the Users for specific community
        //public List<User> ReadAllUsers(Community community)
        //{
        //    return;
        //}

        //Update Community details 

        //Delete community
        //public int Delete() { }



    }


    public class InsertCommunity
    {
        public User UserManager { get; set; }
        public Community Community { get; set; }

        //insert new Community and Manager
        public int Insert(User user, Community community)
        {
            DBservices db = new DBservices();

            return db.insertNewCommunity(community, user);
        }

    }
}
